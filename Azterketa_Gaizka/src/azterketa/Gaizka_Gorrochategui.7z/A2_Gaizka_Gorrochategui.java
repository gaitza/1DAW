package azterketa;

public class A2_Gaizka_Gorrochategui {

	public static void main(String[] args) {
		for (int i = 2; i < 3; i++) {	
			for (int j = 0; j < i; j++) {
				System.out.print("  ");
			}
			
			System.out.println("X");
			
		}
		for (int i = 1; i < 2; i++) {	
			for (int j = 0; j < i; j++) {
				System.out.print("  ");
			}
			
			System.out.println("X   X");
			
		}
		
		for (int i = 1; i < 2; i++) {
			
			System.out.println("X       X");
			
		}
		
		for (int i = 1; i < 2; i++) {	
			for (int j = 0; j < i; j++) {
				System.out.print("  ");
			}
			
			System.out.println("X   X");
			
		}
		for (int i = 2; i < 3; i++) {	
			for (int j = 0; j < i; j++) {
				System.out.print("  ");
			}
			
			System.out.println("X");
			
		}
		
		
	}

}
