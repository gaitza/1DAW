package ariketak;

import java.util.Scanner;

public class Ariketa03_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Scanner
		Scanner sc = new Scanner(System.in);
		// Declaramos la variable
		int adina;
		System.out.println("Zenbat urte dituzu?");
		adina = sc.nextInt();
		System.out.println("Nire adina " + adina + " da.");
		sc.close();
	}

}
